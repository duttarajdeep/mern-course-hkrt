function displayInPickList (userList) {
  if (userList) {
    var myDiv = document.getElementById ('myDiv');
    //Create and append select list
    var selectList = document.createElement ('select');
    selectList.setAttribute ('id', 'available-engg');
    selectList.setAttribute ('multiple', 'multiple');
    selectList.setAttribute ('aria-describedby', 'option-drag-label');
    selectList.setAttribute ('aria-multiselectable', 'true');
    selectList.setAttribute ('role', 'listbox');
    selectList.setAttribute (
      'class',
      'slds-dueling-list__options dueling-class slds-select'
    );
    selectList.setAttribute ('style', 'height: 500px;');
    myDiv.appendChild (selectList);
    userList.forEach (userRec => {
      if (userRec) {
        const option = document.createElement ('option');
        option.setAttribute ('value', userRec.Email);
        option.setAttribute ('class', 'slds-listbox__item');
        option.text = userRec.Name;
        selectList.appendChild (option);
      }
    });
  }
}

const selectedEngineerbtn = document.getElementById ('select-engineer-btn');
const engineerAvailable = document.getElementById ('available-engg');
console.log ('engineerAvailable', engineerAvailable);
selectedEngineerbtn.addEventListener ('click', () => {
  let selectedEngg = engineerAvailable.value;
});

const express = require ('express');
const app = express ();
const port = 3000;

var bodyParser = require ('body-parser');

let noOfRequests = 0;

function middleware (req, res, next) {
  noOfRequests++;
  console.log (noOfRequests);
  next ();
}

// app.use (middleware);

app.use (bodyParser.json ());

app.get ('/', (req, res) => {
  res.sendFile (__dirname + '/index.html');
});

app.post ('/createUser', (req, res) => {
  let user = req.body;
  let age = user.age;

  if (age > 18) {
    res.send ({
      msg: 'Please Apply for A PAN Card',
    });
  } else {
    res.status (411).send ({msg: 'You are not eligible'});
  }
});

app.listen (port, () => {
  console.log (`Listening on port -> ${port}`);
});

const express = require ('express');
const bodyParser = require ('body-parser');
const PORT = 3000;
const app = express ();

let users = [];

app.use (bodyParser.json ());

// signup route
app.post ('/signup', (req, res) => {
  let user = req.body;
  users.push (user);
  console.log (`User ${user.name} created`);
  res.send (`User ${user.name} created`);
});

//login route
app.post ('/login', (req, res) => {
  let userDetail = req.body;
  console.log (userDetail);
  users.forEach (user => {
    if (user.name == userDetail.name && user.password == userDetail.password) {
      res.send (`User ${user.name} Logged In`);
    } else {
      res.send (`Invalid credentials`);
    }
  });
});

// listen
app.listen (PORT, () => {
  console.log (`Server started listening at ${PORT}`);
});

module.exports = app;

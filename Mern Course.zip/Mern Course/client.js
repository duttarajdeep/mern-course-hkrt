const params = {
  name: 'raj',
  age: 9,
  counter: 10,
};

const request = {
  method: 'POST',
  body: JSON.stringify (params),
};

function handleResponse (response) {
  response.json ().then (response => {
    console.log (response);
  });
}

fetch ('http://localhost:3000/createUser', request).then (handleResponse);

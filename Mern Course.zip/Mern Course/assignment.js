function wait (n) {
  return new Promise (resolve => {
    setTimeout (resolve, n * 1000);
  });
}
// console.log ('Waiting...');
// wait (5).then (() => console.log ('Ended...'));
function sleep (n) {
  return new Promise (resolve => {
    setInterval (resolve, n * 1000);
  });
}
// console.log ('Sleeping...');
// sleep (5).then (() => console.log ('Now awake...'));

function waitOneSecond () {
  console.log ('Executing first function');
  return new Promise (resolve => {
    setTimeout (resolve, 1000);
  });
}

function waitTwoSecond () {
  console.log ('Executing second function');

  return new Promise (resolve => {
    setTimeout (resolve, 2000);
  });
}

function waitThreeSecond () {
  console.log ('Executing third function');

  return new Promise (resolve => {
    setTimeout (resolve, 3000);
  });
}

function calculateTime () {
  let startTime = new Date ();
  Promise.all ([
    waitOneSecond,
    waitTwoSecond,
    waitThreeSecond,
  ]).then (values => {
    if (values) {
      let endTime = new Date ();
      let timeTaken = endTime - startTime / 1000;
      return timeTaken;
    }
  });
}

console.log (`Took ${calculateTime ()} seconds to execute`);
